from .node2vec import Node2Vec

"""
setup:
1. genism
2. numpy
3. node2vec
4. tqdm
5. joblib
6. networkx
"""